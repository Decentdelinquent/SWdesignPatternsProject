
package snakegame;


//Command pattern implementation

public class BoundryCollisioned implements Command {
    
    private Stock stock;
    
    public BoundryCollisioned(Stock stock){
        this.stock=stock;
        
    }

    public boolean execute(Snake snake){
       return stock.isBoundryCollisioned(snake);
        
        
    }
    
    
    
}
