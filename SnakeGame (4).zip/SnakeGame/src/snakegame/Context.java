
package snakegame;

import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

//Strategy pattern implementation

public class Context {
    private Dimentions dimention;
    public Context(Dimentions dimention){
        this.dimention=dimention;
    }
    
       public Ellipse2D.Double executeOperation(ArrayList<Ellipse2D.Double> snakeBody){
            
            return dimention.operation(snakeBody);
        }

    
    
}
