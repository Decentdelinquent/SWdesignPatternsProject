
package snakegame;


public class Snake2d {

    
      public static void main(String[] args) {

		new MainScreen();
	}
    }
    
