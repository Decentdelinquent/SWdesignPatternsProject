
package snakegame;

import javax.swing.Timer;

//Factory pattern implementation

public class EasyLevel implements Levels {
    	
        
    public int delay() {
        return 140;
    }

    
    
}
