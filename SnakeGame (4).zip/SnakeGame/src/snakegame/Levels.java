
package snakegame;

//Factory pattern implementation

public interface Levels {
     int delay(); 
    
}
