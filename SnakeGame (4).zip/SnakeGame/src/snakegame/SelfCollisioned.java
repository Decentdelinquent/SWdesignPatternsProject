
package snakegame;


//Command pattern implementation

public class SelfCollisioned implements Command {
        	
     private Stock stock;
    
    public SelfCollisioned(Stock stock){
        this.stock=stock;
        
    }

    public boolean execute(Snake snake){
       return stock.isSelfCollisioned(snake);
        
        
    }
}
