

package snakegame;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;
import javax.swing.Timer;




@SuppressWarnings("serial")
public class GameBoardPanel extends JPanel implements ActionListener {


	private Snake snake;
        private Food proxyFood;
	private InputManager inputManager;
	private Timer gameThread;
	private Timer timerThread;
        private Stock stock;
        private BoundryCollisioned boundryCollisioned;
        private SelfCollisioned selfCollisioned;
        private Broker broker;
        private int level;
	private boolean isGameOver = false;
	private int timer = 0;
	private int playerScore = 0;
        
	public GameBoardPanel(int level) {

		setBackground(Color.BLACK);
		setFocusable(true);
                
                this.level=level;
		snake = Snake.getInstance();
                proxyFood= new Proxy_SnakeFood();
                
                stock=new Stock();
                boundryCollisioned=new BoundryCollisioned(stock);
                selfCollisioned=new SelfCollisioned(stock);
                broker=new Broker();
                
		inputManager = new InputManager(this);
		gameThread = new Timer(getDelay(level), this);
		timerThread = new Timer(1000, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if (isGameOver()) {
					stopGame();
				}

				timer++;
			}
		});

		addKeyListener(inputManager);
	}

	private int getDelay(int level) {

                LevelsFactory levelFactory=new LevelsFactory();
                Levels lev =levelFactory.getLevel(level);
                return lev.delay();
                
	
        }

	public void paintComponent(Graphics g) {
		
            super.paintComponent(g);
            doDrawing(g);
            
	}

	public void doDrawing(Graphics g) {

		Graphics2D g2 = (Graphics2D) g;

		if (isGameRunning()) {

			//snake.setDirection(3);
                        snake.move();
			checkCollision();
			DrawSnakeFood(g2);

		}
                
                DrawStatusbar(g2);

		DrawBoundry(g2);

		DrawSnake(g2,level);
	}

	public void DrawBoundry(Graphics2D g2) {
		for (int i = 0; i < 17; i++) {
			Rectangle2D.Double rect = new Rectangle2D.Double(227.0 - i,
					127.0 - i, 624, 480);

			g2.setColor(Color.YELLOW);
			g2.draw(rect);
		}
	}

        //decorator design pattern implementation
	public void DrawSnake(Graphics2D g2, int snakeColor) {

            ColoredSnake coloredSnake;
            
		if(snakeColor==1){
                
                coloredSnake=new SimpleSnake();
                coloredSnake.drawSnake(snake, g2);
                }
                
                if(snakeColor==2){
                    coloredSnake=new DecoratedBWSnake();
                    coloredSnake.drawSnake(snake, g2);}
                
                if(snakeColor==3){
                    coloredSnake=new DecoratedYPSnake();
                    coloredSnake.drawSnake(snake, g2);}

		
	}
        
	public void DrawSnakeFood(Graphics2D g2) {
		g2.setColor(Color.GREEN);
		g2.fill(proxyFood.getFood());
	}
        
        
	public void DrawStatusbar(Graphics2D g2) {
		g2.setColor(Color.RED);
		g2.setFont(new Font("Comic Sans MS", Font.BOLD, 35));
		g2.drawString("Snake2D Game", 390, 50);
		g2.setColor(Color.ORANGE);
		g2.drawString("mtala3t", 450, 100);

		g2.setFont(new Font("Comic Sans MS", Font.PLAIN, 15));
		g2.setColor(Color.WHITE);
		g2.drawString("Press Esc for exit!", 5, 20);
		g2.drawString("Press Spacebar for pause!", 5, 50);

		g2.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
		g2.drawString("Time: ", 210, 100);
		g2.drawString("Your Score: ", 680, 100);
		g2.setColor(Color.BLUE);
		g2.drawString("" + playerScore, 810, 100);
		g2.drawString("" + timer, 270, 100);

		if (isGameOver()) {
			g2.setColor(Color.WHITE);
			g2.drawString("Game Over!", 480, 350);

		} else if (!isGameRunning()) {
			g2.setColor(Color.WHITE);
			g2.drawString("Press SpaceBar to Start Game!", 400, 500);
		}

	}
        
        

        public void changeSnakeDirection(int direction) {
		this.snake.setDirection(direction);
	}

        
        //command pattern implementation
	public void checkCollision() {

		if(broker.collisioned(boundryCollisioned, snake)) {
                    isGameOver = true;
                    
                    stopGame();
                } 
                
                if(broker.collisioned(selfCollisioned, snake)) {
                    isGameOver = true;
                    
                    stopGame();
                } 
                
                

		if (isFoodCollisioned()) {

			snake.eat();
                        proxyFood= new Proxy_SnakeFood();
			playerScore += 5;
		}
	}

	public boolean isFoodCollisioned() {

		boolean collisionedWithFood = false;

		int direction = snake.getDirection();

		Ellipse2D.Double head = snake.getHead();
                
                  //Proxy pattern implementation
                  
		if (direction == 1) {
			if (((head.getCenterY() == proxyFood.getFood().getCenterY())&& (head.getCenterX() == proxyFood.getFood().getCenterX()))
                               ) {
				collisionedWithFood = true;
			} else
				collisionedWithFood = false;
		} else if (direction == 2) {

			if (((head.getCenterY() == proxyFood.getFood().getCenterY())
					&& (head.getCenterX() == proxyFood.getFood().getCenterX()))) {
				collisionedWithFood = true;
			} else
				collisionedWithFood = false;

		} else if (direction == 3) {
			if (((head.getCenterX() == proxyFood.getFood().getCenterX())
					&& (head.getCenterY() == proxyFood.getFood().getCenterY()))) {
				collisionedWithFood = true;
			} else
				collisionedWithFood = false;
		} else if (direction == 4) {
			if (((head.getCenterX() == proxyFood.getFood().getCenterX())
					&& (head.getCenterY() == proxyFood.getFood().getCenterY())
                                )) {
				collisionedWithFood = true;
			} else
				collisionedWithFood = false;
		}

		return collisionedWithFood;

	}
        
	public void startGame() {

		if (gameThread.isRunning()) {
			gameThread.restart();
			timerThread.restart();
                       
		} else {
			gameThread.start();
			timerThread.start();
                       
		}}

	public void pauseGame() {

		gameThread.stop();
		timerThread.stop();
		repaint();
	}

	public void stopGame() {

		gameThread.stop();
		timerThread.stop();
	}
        
	public boolean isGameRunning() {
		return gameThread.isRunning() && !isGameOver();
	}

	public boolean isGameOver() {
		return isGameOver;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {

		repaint();

	}

}
