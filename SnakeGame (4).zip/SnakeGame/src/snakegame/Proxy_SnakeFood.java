
package snakegame;

import java.awt.geom.Ellipse2D;
import java.util.Random;

//Proxy pattern implementation

public class Proxy_SnakeFood implements Food{
 

	private SnakeFood snakeFood;

	public Proxy_SnakeFood() {

	}
	
	public Ellipse2D.Double getFood() {
            if(snakeFood==null){
                snakeFood=new SnakeFood();
            }
		return snakeFood.getFood();
	}
        
        
}

    

