
package snakegame;

//Command pattern implementation

public class Broker {
    
    public boolean collisioned(Command command,Snake snake){
        
       return command.execute(snake);
        
    }
    
}
