
package snakegame;

import java.awt.geom.Ellipse2D;

/**
 *
 * @author sheha
 */
interface Food {
    public Ellipse2D.Double getFood();
    
}
