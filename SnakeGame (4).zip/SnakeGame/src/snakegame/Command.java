
package snakegame;

//Command pattern implementation

public interface Command {
 boolean execute(Snake snake);

}
