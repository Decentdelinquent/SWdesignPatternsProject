
package snakegame;

import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

//Strategy pattern implementation

public interface Dimentions {
    
    Ellipse2D.Double operation(ArrayList<Ellipse2D.Double> snakeBody);
}
