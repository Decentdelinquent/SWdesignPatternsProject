
package snakegame;

//Factory pattern implementation

public class LevelsFactory {
    
    public Levels getLevel(int level){
        
        if(level==0){
            return null;
        }
        if(level==1){
            return new EasyLevel();
        }
        if(level==2){
            return new NormalLevel();
        }
        if(level==3){
            return new HardLevel();
        }
      return null;  
    }
    
    
}
