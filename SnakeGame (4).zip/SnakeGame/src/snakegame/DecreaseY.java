
package snakegame;

import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

//Strategy pattern implementation

public class DecreaseY implements Dimentions{
    
    public Ellipse2D.Double operation(ArrayList<Ellipse2D.Double> snakeBody) {
		Ellipse2D.Double temp = (Ellipse2D.Double) snakeBody.get(0);
		Ellipse2D.Double elli = new Ellipse2D.Double(temp.x, temp.y - 16,
				temp.getWidth(), temp.getHeight());

		return snakeBody.set(0, (Ellipse2D.Double) elli);
	}
    
}
