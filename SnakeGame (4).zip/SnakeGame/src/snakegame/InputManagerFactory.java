
package snakegame;


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


public class InputManagerFactory {

    private GameBoardPanel GameBoard;

    public InputManagerFactory(GameBoardPanel gameBoard) {
        this.GameBoard = gameBoard;
    }

    public KeyListener createKeyListener() {
        return new InputManager();
    }

    private class InputManager implements KeyListener {

        public void keyTyped(KeyEvent e) {
        }

        public void keyPressed(KeyEvent e) {
            int key = e.getKeyCode();
            handleKeyPressed(key);
        }

        public void keyReleased(KeyEvent e) {
        }

        private void handleKeyPressed(int keyCode) {
            switch (keyCode) {
                case KeyEvent.VK_UP:
                    GameBoard.changeSnakeDirection(1);
                    break;
                case KeyEvent.VK_DOWN:
                    GameBoard.changeSnakeDirection(2);
                    break;
                case KeyEvent.VK_RIGHT:
                    GameBoard.changeSnakeDirection(3);
                    break;
                case KeyEvent.VK_LEFT:
                    GameBoard.changeSnakeDirection(4);
                    break;
                case KeyEvent.VK_SPACE:
                    toggleGameRunningState();
                    break;
                case KeyEvent.VK_ESCAPE:
                    exitGame();
                    break;
            }
        }

        private void toggleGameRunningState() {
            if (GameBoard.isGameRunning()) {
                GameBoard.pauseGame();
            } else {
                GameBoard.startGame();
            }
        }

        private void exitGame() {
            System.exit(0);
        }
    }
}


