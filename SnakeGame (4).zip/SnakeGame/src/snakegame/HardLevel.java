
package snakegame;

//Factory pattern implementation

public class HardLevel implements Levels{
    public int delay() {
        return 40;
    }
    
}
