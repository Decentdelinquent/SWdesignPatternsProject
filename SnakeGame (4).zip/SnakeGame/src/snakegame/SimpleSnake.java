
package snakegame;


import java.awt.Color;
import java.awt.Graphics2D;

//decorator pattern implementation


public class SimpleSnake implements ColoredSnake{
   
    @Override
    public void drawSnake(Snake snake, Graphics2D g2){
    
    for (int i = 0; i < snake.getSnakeBody().size(); i++) {

			if (i == 0) {
				g2.setColor(Color.RED);
				g2.fill(snake.getSnakeBody().get(i));

			} else {
				g2.setColor(Color.ORANGE);
				g2.draw(snake.getSnakeBody().get(i));
			}
    
    }
}
}


    

