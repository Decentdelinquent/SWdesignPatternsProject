
package snakegame;

//Factory pattern implementation

public class NormalLevel implements Levels {
    public int delay() {
        return 70;
    }
    
}
