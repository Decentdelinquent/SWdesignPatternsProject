package snakegame;
import java.awt.Color;
import java.awt.Graphics2D;


//decorator pattern implementation

public interface ColoredSnake {
    void drawSnake(Snake snake, Graphics2D g2);
}