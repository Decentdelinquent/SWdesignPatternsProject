/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package snake2ddecorator;

import java.awt.Color;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

/**
 *
 * @author layla
 */
public class Snake2d {

    /**
     * @param args the command line arguments
     */
  
      public static void main(String[] args) {
          
          
		new MainScreen();
         /** 
          // Create an instance of the Snake
        Snake snake = new Snake();

        // Create an instance of the SnakeDecorator and pass the snake
        SnakeDecorator decoratedSnake = new SnakeDecorator(snake);

        // Set the desired color
        Color selectedColor = Color.RED;
        decoratedSnake.setColor(selectedColor);

        // Now you can use the decoratedSnake object to access the decorated snake with the selected color
        ArrayList<Ellipse2D.Double> snakeBody = decoratedSnake.getSnakeBody();
        // Use the snakeBody for rendering or any other purposes**/
    }
}

	
