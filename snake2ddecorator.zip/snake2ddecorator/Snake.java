/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package snake2ddecorator;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

/**
 *
 * @author layla
 * 
 */

interface abstractSnake{

void colorSnake(Graphics2D g);
}

public class Snake implements abstractSnake{
    private static Snake instance = null;

	private static final int DEFAULT_SNAKE_LENGTH = 5;
	private static final int DEFAULT_SNAKE_DIRECTION = 3;

	private static ArrayList<Ellipse2D.Double> snakeBody = new ArrayList<Ellipse2D.Double>();

	private int direction;
		Snake() {direction = DEFAULT_SNAKE_DIRECTION;}


	public static Snake getInstance() {
		if (instance==null){
			instance=new Snake();

		}

		for (int i = 0; i < DEFAULT_SNAKE_LENGTH; i++) {
			snakeBody.add(new Ellipse2D.Double(355 - i * 16, 191, 16, 16));
		}
		return instance;
	}

	public void setDirection(int dir) {
		if (direction >= 3 && dir < 3) {
			this.direction = dir;
		} else if (direction <= 2 && dir > 2) {
			this.direction = dir;
		}
	}

	public void move() {
		for (int i = getLength() - 1; i > 0; i--) {
			snakeBody.set(i, (Ellipse2D.Double) snakeBody.get(i - 1));
		}

		if (direction == 1) {
			decreaseY();
		} else if (direction == 2) {
			increaseY();
		} else if (direction == 3) {
			increaseX();
		} else if (direction == 4) {
			decreaseX();
		}
	}

	public void eat() {

		snakeBody.add(snakeBody.get(getLength() - 1));
	}

	public void increaseY() {
		Ellipse2D.Double temp = (Ellipse2D.Double) snakeBody.get(0);
		Ellipse2D.Double elli = new Ellipse2D.Double(temp.x, temp.y + 16,
				temp.getWidth(), temp.getHeight());

		snakeBody.set(0, (Ellipse2D.Double) elli);

	}

	public void decreaseY() {
		Ellipse2D.Double temp = (Ellipse2D.Double) snakeBody.get(0);
		Ellipse2D.Double elli = new Ellipse2D.Double(temp.x, temp.y - 16,
				temp.getWidth(), temp.getHeight());

		snakeBody.set(0, (Ellipse2D.Double) elli);
	}

	public void increaseX() {
		Ellipse2D.Double temp = (Ellipse2D.Double) snakeBody.get(0);
		Ellipse2D.Double elli = new Ellipse2D.Double(temp.x + 16, temp.y,
				temp.getWidth(), temp.getHeight());

		snakeBody.set(0, (Ellipse2D.Double) elli);
	}

	public void decreaseX() {
		Ellipse2D.Double temp = (Ellipse2D.Double) snakeBody.get(0);
		Ellipse2D.Double elli = new Ellipse2D.Double(temp.x - 16, temp.y,
				temp.getWidth(), temp.getHeight());

		snakeBody.set(0, (Ellipse2D.Double) elli);
	}

	public ArrayList<Ellipse2D.Double> getSnakeBody() {
		return snakeBody;
	}

	public int getLength() {
		return snakeBody.size();
	}

	public int getDirection() {

		return direction;
	}

	public Ellipse2D.Double getHead() {

		return snakeBody.get(0);

 
	}

        @Override
        public void colorSnake(Graphics2D g){
        
        
for (int i = 0; i < snakeBody.size(); i++) {

			if (i == 0) {
				g.setColor(Color.RED);
				g.fill(snakeBody.get(i));

			} else {
				g.setColor(Color.ORANGE);
				g.draw(snakeBody.get(i));
			}
        
        }
        //DECORATOR

}

class SnakeBlueYellowDecorator implements abstractSnake{
    
    public void colorSnake(Graphics2D g){

for (int i = 0; i < snakeBody.size(); i++) {

			if (i == 0) {
				g.setColor(Color.BLUE);
				g.fill(snakeBody.get(i));

			} else {
				g.setColor(Color.YELLOW);
				g.draw(snakeBody.get(i));
			}
}


}

class SnakeGreenWhiteDecorator implements abstractSnake{
    public void colorSnake(Graphics2D g){

for (int i = 0; i < snakeBody.size(); i++) {

			if (i == 0) {
				g.setColor(Color.GREEN);
				g.fill(snakeBody.get(i));

			} else {
				g.setColor(Color.WHITE);
				g.draw(snakeBody.get(i));
			}
}


}

                
    
}


}}
